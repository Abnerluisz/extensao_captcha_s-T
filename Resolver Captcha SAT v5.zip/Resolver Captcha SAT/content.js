async function encontrarCaptchaResolverEInserir() {
  const img = document.querySelector(".sat-captcha-image-container img");
  const input = document.querySelector("input[placeholder='Digite o texto']");

  if (!img || !input) {
    console.error("Imagem ou input não encontrados.");
    return;
  }

  try {
    mostrarNotificacao("Resolvendo CAPTCHA... 🧐");

    const imagemBase64 = await converterImagemParaBase64(img);

    const resposta = await fetch("https://45.140.19.247:5000/resolver-captcha", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ imagem: imagemBase64 }),
      mode: 'cors',
      credentials: 'omit'
    }).catch(err => {
      console.error("Erro na requisição:", err);
      throw err;
    });

    const json = await resposta.json();
    const resultado = json.resultado;

    if (resultado) {
      input.value = resultado;
      console.log("CAPTCHA resolvido:", resultado);
      mostrarNotificacao(`CAPTCHA resolvido: [ ${resultado} ] 😆`, "sucesso");

      localStorage.setItem("ultimoCaptcha", resultado);
    } else {
      console.log("Não foi possível resolver o captcha. 🤯");
      mostrarNotificacao("Não foi possível resolver o CAPTCHA.", "erro");
    }

  } catch (erro) {
    console.error("Erro ao resolver captcha:", erro);
    mostrarNotificacao("Erro ao resolver o CAPTCHA. 😭", "erro");
  }
}


function converterImagemParaBase64(imgElement) {
  return new Promise((resolve, reject) => {
    try {
      const canvas = document.createElement("canvas");
      canvas.width = imgElement.naturalWidth;
      canvas.height = imgElement.naturalHeight;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(imgElement, 0, 0);
      const dataURL = canvas.toDataURL("image/png");
      resolve(dataURL.replace(/^data:image\/(png|jpg);base64,/, ""));
    } catch (err) {
      reject(err);
    }
  });
}

// Escuta o botão "mirar" da popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.acao === "ativarMira") {
    encontrarCaptchaResolverEInserir();
  }
});

// Sempre executa ao carregar
encontrarCaptchaResolverEInserir();


// function observarErroCaptcha() {
//   const observer = new MutationObserver(() => {
//     const erroCaptcha = document.querySelector("#__SatMessageBox .sat-vs-error");
//     if (erroCaptcha && erroCaptcha.innerText.includes("Os caracteres digitados não coincidem")) {
//       console.log("Erro de captcha detectado. Reexecutando resolução...");

//       // Tenta resolver novamente
//       encontrarCaptchaResolverEInserir();
//     }
//   });

//   observer.observe(document.body, { childList: true, subtree: true });
// }

// // Inicia o observador de erro
// observarErroCaptcha();


let podeTentarResolver = true;

// Atalhos de teclado: F2 ou Ctrl+Q
document.addEventListener("keydown", function (e) {
  if (!podeTentarResolver) return;

  const teclaF2 = e.key === "F2";
  const teclaCtrlQ = e.ctrlKey && e.key.toLowerCase() === "q";

  if (teclaF2 || teclaCtrlQ) {
    console.log("Atalho detectado. Iniciando resolução do CAPTCHA...");
    podeTentarResolver = false;
    encontrarCaptchaResolverEInserir();

    // Libera tentativa após 2 segundos
    setTimeout(() => {
      podeTentarResolver = true;
    }, 2000);
  }
});


// Escuta cliques no botão de refresh, mesmo que ele seja recriado
document.addEventListener("click", (e) => {
  const botao = e.target.closest("#Body_Main_Main_sepConsultaNfpe_ctl23_btn0");
  if (botao) {
    console.log("Botão de refresh clicado. Tentando resolver o captcha novamente...");
    setTimeout(() => {
      encontrarCaptchaResolverEInserir();
    }, 500); // Pode ajustar esse tempo se necessário
  }
});




document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get("ultimoCaptcha", (dados) => {
    if (dados.ultimoCaptcha) {
      const spanCaptcha = document.getElementById("captcha-id");
      if (spanCaptcha) {
        spanCaptcha.textContent = dados.ultimoCaptcha;
      }
    }
  });

  // Botão quebrar captcha
  const btnMirar = document.getElementById("mirar");
  if (btnMirar) {
    btnMirar.addEventListener("click", () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, { acao: "ativarMira" });
      });
    });
  }
});


function mostrarNotificacao(mensagem, tipo = "info") {
  const container = document.createElement("div");
  container.textContent = mensagem;

  // Estilo base
  container.style.position = "fixed";
  container.style.bottom = "20px";
  container.style.right = "20px"; // <-- AQUI! canto inferior direito
  container.style.padding = "10px 20px";
  container.style.borderRadius = "8px";
  container.style.boxShadow = "0 0 10px rgba(0,0,0,0.3)";
  container.style.color = "#fff";
  container.style.fontSize = "14px";
  container.style.zIndex = 9999;
  container.style.transition = "all 0.5s ease-out";
  container.style.opacity = "0";
  container.style.transform = "translateY(20px)";

  if (tipo === "sucesso") container.style.background = "#28a745";
  else if (tipo === "erro") container.style.background = "#dc3545";
  else container.style.background = "#007bff"; // info

  document.body.appendChild(container);

  setTimeout(() => {
    container.style.opacity = "1";
    container.style.transform = "translateY(0)";
  }, 100);

  setTimeout(() => {
    container.style.opacity = "0";
    container.style.transform = "translateY(20px)";
    setTimeout(() => container.remove(), 500);
  }, 3000);
}
