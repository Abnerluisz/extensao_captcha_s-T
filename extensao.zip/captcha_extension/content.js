let modoMiraAtivado = false;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.acao === "ativarMira") {
    modoMiraAtivado = true;
    alert("Modo mira ativado! Clique numa imagem para resolver o captcha.");
  }
});

document.addEventListener("click", async (event) => {
  if (!modoMiraAtivado) return;

  const elementoClicado = event.target;

  if (elementoClicado.tagName === "IMG") {
    modoMiraAtivado = false;

    try {
      const imagemBase64 = await converterImagemParaBase64(elementoClicado);
      
      const resposta = await fetch("http://localhost:5000/resolver-captcha", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ imagem: imagemBase64 })
      });

      const json = await resposta.json();
      alert("CAPTCHA Resolvido: " + json.resultado);
    } catch (erro) {
      console.error("Erro ao resolver captcha:", erro);
      alert("Erro ao resolver captcha");
    }
  }
});

function converterImagemParaBase64(imgElement) {
  return new Promise((resolve, reject) => {
    try {
      const canvas = document.createElement("canvas");
      canvas.width = imgElement.naturalWidth;
      canvas.height = imgElement.naturalHeight;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(imgElement, 0, 0);
      const dataURL = canvas.toDataURL("image/png");
      resolve(dataURL.replace(/^data:image\/(png|jpg);base64,/, ""));
    } catch (err) {
      reject(err);
    }
  });
}
