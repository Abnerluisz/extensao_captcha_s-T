chrome.runtime.onInstalled.addListener(() => {
    console.log("Captcha Resolver instalado.");
  });
  